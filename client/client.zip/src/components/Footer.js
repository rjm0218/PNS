
function Footer() {
	
	return (
	
		<div className="footer-div">	
			<p>&copy; 2024 SynnerSanctuary. All rights reserved.</p>
			<p>Product by: Lunar</p>
		</div>

	);
}

export default Footer;